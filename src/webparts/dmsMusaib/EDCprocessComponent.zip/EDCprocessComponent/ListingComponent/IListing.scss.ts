/* tslint:disable */
require("./IListing.css");
const styles = {

};

export default styles;
/* tslint:enable */