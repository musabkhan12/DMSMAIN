/* tslint:disable */
require("./EditComponent.css");
const styles = {

};

export default styles;
/* tslint:enable */