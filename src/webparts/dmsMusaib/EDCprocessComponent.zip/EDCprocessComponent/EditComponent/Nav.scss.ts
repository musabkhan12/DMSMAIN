/* tslint:disable */
require("./Nav.css");
const styles = {

};

export default styles;
/* tslint:enable */