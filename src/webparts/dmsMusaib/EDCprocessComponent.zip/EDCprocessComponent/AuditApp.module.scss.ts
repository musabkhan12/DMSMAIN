/* tslint:disable */
require("./AuditApp.module.css");
const styles = {
  auditApp: 'auditApp_738f61f6',
  teams: 'teams_738f61f6',
  welcome: 'welcome_738f61f6',
  welcomeImage: 'welcomeImage_738f61f6',
  links: 'links_738f61f6',
  'cl-3': 'cl-3_738f61f6',
  'cl-12': 'cl-12_738f61f6',
  sec: 'sec_738f61f6',
  err: 'err_738f61f6',
  errCls: 'errCls_738f61f6',
  errCh: 'errCh_738f61f6',
  modal: 'modal_738f61f6',
  width: 'width_738f61f6',
  none: 'none_738f61f6',
  modalcontent: 'modalcontent_738f61f6',
  close: 'close_738f61f6'
};

export default styles;
/* tslint:enable */