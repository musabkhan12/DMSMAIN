/* tslint:disable */
require("./Form.css");
const styles = {

};

export default styles;
/* tslint:enable */