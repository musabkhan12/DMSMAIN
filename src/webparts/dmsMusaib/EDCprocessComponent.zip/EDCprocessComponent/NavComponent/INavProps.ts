export interface INavProps {
   
  }
  